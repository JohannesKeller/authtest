$( document ).ready(function() {
$("#ausführen").click( function()
{

  console.log(btoa('beckerth:S9CZ8ERA'));
  console.log($('input').val());

  var felixlink = $('input').val();
  
  var cors = "";
  $("#eins").html('<i class="fas fa-spinner fa-pulse"></i>');
  
  $.ajax({
    url: cors + "https://felix.hs-furtwangen.de",
    
    headers: {
      // "Authorization": "Basic YmVja2VydGg6UzlDWjhFUkE=",
      // "Access-Control-Allow-Credentials": "true"
      //beckerth: Basic YmVja2VydGg6UzlDWjhFUkE= /  beckerth.hfu: Basic YmVja2VydGguaGZ1OlJlc3QjMjAxNw==
    }
  }).done(function () {
    $("#eins").html('<i class="fas fa-check"></i>');

  console.log();




  $("#zwei").html('<i class="fas fa-spinner fa-pulse"></i>')
  //Start der Shibboleth-Authentifizierung
  $.ajax({
    url: cors + "https://felix.hs-furtwangen.de/shib/",
    // headers: {
      //   "Authorization": "Basic YmVja2VydGg6UzlDWjhFUkE=",
      //   "username": "beckerth",
      //   "password": "S9CZ8ERA"
      // }
    })
    .done(function (data) {
      console.log(data);
      $("#zwei").html('<i class="fas fa-check"></i>');
      var dataXML = $.parseXML(data);
      var input = $("input", dataXML);
      var relayState;
      var samlRequest;
      var attrs = [];
      input.each(function () {
        //console.log($(this).attr("value"));
        attrs.push($(this).attr("value"));
      })
      var relayState = attrs[0];
      var samlRequest = attrs[1];
      
      // console.log(samlRequest);
      // console.log(relayState);
      



      //SAMLRequest per POST verschicken
      $("#drei").html('<i class="fas fa-spinner fa-pulse"></i>')
      $.ajax({
        url: cors + "https://idp2.hs-furtwangen.de/idp/profile/SAML2/POST/SSO",
        method: "POST",
        headers: {
          "Authorization": "Basic YmVja2VydGg6UzlDWjhFUkE="
          
        },
        data: {
          "RelayState": relayState,
          "SAMLRequest": samlRequest,
        },
        contentType: "application/x-www-form-urlencoded"
        
      })
      .done(function(data){
        $("#drei").html('<i class="fas fa-check"></i>');
        console.log(data);
        var dataXML = $.parseXML(data);
        var samlResponse;
        var input = $("input", dataXML);
        var attrs1 = [];        
        input.each(function(){
          attrs1.push($(this).attr("value"))
        });
        var samlResponse = attrs1[1];
        console.log(data);
        //console.log(samlResponse);
        // console.log(data);
        //console.log(dataXML);
        




        //SAMLResponse per POST verschicken
        $("#vier").html('<i class="fas fa-spinner fa-pulse"></i>')
        $.ajax({
          url: cors + "https://felix.hs-furtwangen.de/Shibboleth.sso/SAML2/POST",
          method: "POST",
          headers: {"Authorization": "Basic YmVja2VydGg6UzlDWjhFUkE="}, //YmVja2VydGg6UzlDWjhFUkE=
          data: {
            "SAMLResponse": samlResponse
          }
        })
        .done(function(data){
          $("#vier").html('<i class="fas fa-check"></i>');
          console.log(data);
          
          
        
          
          //Authentifizierung abschließen
          $("#fünf").html('<i class="fas fa-spinner fa-pulse"></i>')
          $.ajax({
            url: cors + "https://felix.hs-furtwangen.de/shib/",
            method: "GET",
            headers: {"Authorization": "Basic YmVja2VydGg6UzlDWjhFUkE="}
            
          }).done(function(data){
            $("#fünf").html('<i class="fas fa-check"></i>');





            $("#sechs").html('<i class="fas fa-spinner fa-pulse"></i>')
            var cors = "";
            $.ajax({
              url: felixlink,
              method: "GET",
              headers: {"Authorization": "Basic YmVja2VydGg6UzlDWjhFUkE="},
              Cookie: "JSESSIONID=55E6A15A4681D1B958E02296CF60BAD6; _shibsession_64656661756c7468747470733a2f2f66656c69782e68732d6675727477616e67656e2e64652f73686962626f6c6574682f6f6c61742f7370=_afa7836622fd0d39efc7b3d27c6f813f; OLAT-UI-TIMESTAMP=1528311839365",
              // beforeSend: function( xhr ) {
                //   xhr.setRequestHeader("Authorization", "Basic YmVja2VydGg6UzlDWjhFUkE=");
                //        },
                // beforeSend: function( xhr ) {
                  //   xhr.setRequestHeader("Access-Control-Allow-Headers", "X-Requested-With");
                  //        },
                  
                }).done(function(data){
                  console.log(data);
                  $("#sechs").html('<i class="fas fa-check"></i>');
                  $("#answer").html('data');
                  $("#answer").html(getXmlString(data));
                }).fail(function (data) {
                  console.log(data);
                  $("#sechs").html('<i class="fas fa-times"></i>');
                });
                
            
          })
          
        })
        
        
      })   
    });
  });
});
});

function getXmlString(xml) {
  if (window.ActiveXObject) { return xml.xml; }
  return new XMLSerializer().serializeToString(xml);
}
// alert(getXmlString(xml));